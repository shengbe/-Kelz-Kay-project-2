using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ScriptureMemorizer.Models;

namespace ScriptureMemorizer.Services
{
    public class ScriptureService
    {
        private List<Scripture> _scriptures;
        private readonly string filePath;

        public ScriptureService()
        {
            filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "data", "scriptures.json");
            LoadScriptures();
        }

        private void LoadScriptures()
        {
            if (File.Exists(filePath))
            {
                try
                {
                    string json = File.ReadAllText(filePath);
                    _scriptures = JsonConvert.DeserializeObject<List<Scripture>>(json) ?? new List<Scripture>();
                }
                catch
                {
                    _scriptures = new List<Scripture>();
                }
            }
            else
            {
                _scriptures = new List<Scripture>();
            }
        }

        private void SaveScriptures()
        {
            string json = JsonConvert.SerializeObject(_scriptures, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        public List<Scripture> GetAllScriptures()
        {
            return _scriptures;
        }

        public Scripture GetRandomScripture()
        {
            if (_scriptures.Count == 0)
            {
                throw new Exception("No scriptures available. Please add scriptures.");
            }

            Random _random = new Random();
            return _scriptures[_random.Next(_scriptures.Count)];
        }

        public string HideWords(string scriptureText, int wordsToHide)
        {
            string[] words = scriptureText.Split(' ');
            List<int> visibleIndexes = new List<int>();

            for (int i = 0; i < words.Length; i++)
            {
                if (words[i] != "_____") 
                {
                    visibleIndexes.Add(i);
                }
            }

            if (visibleIndexes.Count == 0) return scriptureText;

            Random random = new Random();
            
            for (int i = 0; i < wordsToHide && visibleIndexes.Count > 0; i++)
            {
                int randomIndex = random.Next(visibleIndexes.Count);
                int index = visibleIndexes[randomIndex]; 
                words[index] = "_____";  
                visibleIndexes.RemoveAt(randomIndex); 
            }

            return string.Join(" ", words);
        }

        public void AddScripture(Scripture newScripture)
        {
            newScripture.Timestamp = DateTime.Now;
            _scriptures.Add(newScripture);
            SaveScriptures();
        }

        public void UpdateScripture(string reference, string newText)
        {
            var scripture = _scriptures.FirstOrDefault(s => s.Reference == reference);
            if (scripture != null)
            {
                scripture.Text = newText;
                scripture.Timestamp = DateTime.Now;
                SaveScriptures();
            }
        }

        public void DeleteScripture(string reference)
        {
            _scriptures.RemoveAll(s => s.Reference == reference);
            SaveScriptures();
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using ScriptureMemorizer.Services;
using ScriptureMemorizer.Models;
using System.Collections.Generic;

namespace ScriptureMemorizer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ScriptureService _scriptureService;
        
        public HomeController()
        {
            _scriptureService = new ScriptureService();
        }

        public IActionResult Index()
        {
            List<Scripture> scriptures = _scriptureService.GetAllScriptures();
            ViewBag.Scriptures = scriptures;
            return View();
        }
    }
}

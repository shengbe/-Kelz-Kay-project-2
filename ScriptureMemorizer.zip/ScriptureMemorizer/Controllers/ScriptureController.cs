using Microsoft.AspNetCore.Mvc;
using ScriptureMemorizer.Services;
using ScriptureMemorizer.Models;
using System.Collections.Generic;

namespace ScriptureMemorizer.Controllers
{
    public class ScriptureController : Controller
    {
        private readonly ScriptureService _scriptureService;
        private static string _currentScripture = "";
        private static int _wordsHidden = 0;

        public ScriptureController()
        {
            _scriptureService = new ScriptureService();
        }

        public IActionResult Index()
        {
            try
            {
                var scripture = _scriptureService.GetRandomScripture();
                _currentScripture = scripture.Text;
                ViewBag.Scripture = _currentScripture;
                ViewBag.Reference = scripture.Reference;
            }
            catch
            {
                ViewBag.Scripture = "No scriptures available. Please add some.";
                ViewBag.Reference = "Error";
            }
            return View();
        }

        [HttpPost]
        public IActionResult HideWords()
        {
            _wordsHidden += 2;
            ViewBag.Scripture = _scriptureService.HideWords(_currentScripture, _wordsHidden);
            return View("Index");
        }

        [HttpPost]
        public IActionResult Reset()
        {
            _wordsHidden = 0;
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Manage()
        {
            var scriptures = _scriptureService.GetAllScriptures();
            return View(scriptures);
        }

        [HttpPost]
        public IActionResult AddScripture(string reference, string text)
        {
            if (!string.IsNullOrEmpty(reference) && !string.IsNullOrEmpty(text))
            {
                _scriptureService.AddScripture(new Scripture { Reference = reference, Text = text });
            }
            return RedirectToAction("Manage");
        }

        [HttpPost]
        public IActionResult EditScripture(string reference, string newText)
        {
            if (!string.IsNullOrEmpty(reference) && !string.IsNullOrEmpty(newText))
            {
                _scriptureService.UpdateScripture(reference, newText);
            }
            return RedirectToAction("Manage");
        }

        [HttpPost]
        public IActionResult DeleteScripture(string reference)
        {
            if (!string.IsNullOrEmpty(reference))
            {
                _scriptureService.DeleteScripture(reference);
            }
            return RedirectToAction("Manage");
        }
    }
}

namespace ScriptureMemorizer.Models
{
    public class Word
    {
        public string Text { get; set; } = string.Empty;
        public bool IsHidden { get; set; }
    }
}

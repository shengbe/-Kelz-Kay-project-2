namespace ScriptureMemorizer.Models
{
    public class Scripture
    {
        public string Reference { get; set; } = string.Empty;
        public string Text { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.Now; // Added timestamp to track when it was added or updated
    }
}
